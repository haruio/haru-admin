Haru Example Memo
=================

Haru를 이용한 샘플 메모 앱 예제입니다.
지원되는 기능은 다음과 같습니다.
 - 로그인, 회원가입 및 소셜 로그인 (Facebook, KakaoTalk)
 - 메모를 클라우드에 저장하고, 불러오고, 쓸 수 있음

<b>NOTE : </b>앱을 실행시키기 전에, haru.io에서 새로운 프로젝트를 만든 후, 이 앱의 App 클래스로 가서 APP 키와 SDK 키를
새로 만든 프로젝트의 키로 교체해 주시기 바랍니다.

<code>Haru.init(APP_KEY, SDK_KEY); // 이 부분을 수정</code>
